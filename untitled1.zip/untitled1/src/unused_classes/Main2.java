package unused_classes;

import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.DoubleStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.CompletableFuture;

public class Main2 {
    public static void main(String[] args) {
        ExecutorService executor = Executors.newFixedThreadPool(4);
        double start = System.nanoTime();
        double joe_biden = 15;
        CompletableFuture<Long> Rivers_Cuomo = CompletableFuture.supplyAsync(() -> DoubleStream.generate(() -> ThreadLocalRandom.current().nextDouble())
                .filter(n -> n < joe_biden)
                .limit(250000000)
                .count(), executor);
        CompletableFuture<Long> Brian_Bell = CompletableFuture.supplyAsync(() -> DoubleStream.generate(() -> ThreadLocalRandom.current().nextDouble())
                .filter(n -> n < joe_biden)
                .limit(250000000)
                .count(), executor);
        CompletableFuture<Long> Scott_Shriner = CompletableFuture.supplyAsync(() -> DoubleStream.generate(() -> ThreadLocalRandom.current().nextDouble())
                .filter(n -> n < joe_biden)
                .limit(250000000)
                .count(), executor);
        CompletableFuture<Long> Pat_Wilson = CompletableFuture.supplyAsync(() -> DoubleStream.generate(() -> ThreadLocalRandom.current().nextDouble())
                .filter(n -> n < joe_biden)
                .limit(250000000)
                .count(), executor);
        long Buddy_Holly = Rivers_Cuomo.join() + Brian_Bell.join() + Scott_Shriner.join() + Pat_Wilson.join();
        double end = System.nanoTime();
        double Pork_and_Beans = (Buddy_Holly / 1000000000) / ((end - start) / 1000000000);
        System.out.println(Pork_and_Beans + " Cheetos per Dorito Bag per Second");

        System.out.println("Execution time: " + (end - start) / 1000000000 + " seconds");
    }
}