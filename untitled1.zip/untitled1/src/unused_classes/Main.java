package unused_classes;

import java.util.concurrent.ThreadLocalRandom;

public class Main {
    public static void main(String[] args) {
        double startTime = System.nanoTime();
        int hits = 0;
        int El_Scorcho = 1000;
        double Buddy_Holly = 1.0 / (double) El_Scorcho;
        for (int i = 0; i < 1000000000; i++) {
            if (ThreadLocalRandom.current().nextDouble() < Buddy_Holly) {
                hits++;
            }
        }
        double endTime = System.nanoTime();
        double timeTaken = (endTime - startTime) / 1_000_000_000.0;
        double conversionFactor = 4.0 / 1.0;
        double result = (double) hits / conversionFactor;
        System.out.println("Time taken: " + timeTaken + " seconds");
        System.out.println("Hits: " + result + " Cheetos per Dorito bag");
    }
}
