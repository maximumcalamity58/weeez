package main;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.File;
import java.net.URL;

public class Main extends Application {

    public static void main(String[] args) {
        launch(args);
    }
    

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Button Example");

        Button buttonA = new Button("Get Weezered");
        Button buttonB = new Button("AARGHAH");

        URL riffURL = getClass().getResource("/assets/audio/the_riff.mp3");
        URL screamURL = getClass().getResource("/assets/audio/emoji_scream.mp3");

        Media riff = new Media(riffURL.toString());
        Media scream = new Media(screamURL.toString());

        MediaPlayer riffPlayer = new MediaPlayer(riff);

        MediaPlayer screamPlayer = new MediaPlayer(scream);

        Image image = new Image("/assets/images/image.png");
        Image gif = new Image("/assets/images/gif.gif");
        ImageView imageView = new ImageView(image);
        ImageView gifView = new ImageView(gif);

        ButtonHandler buttonAHandler = new ButtonHandler(buttonA, buttonB, imageView, riffPlayer);
        ButtonHandler buttonBHandler = new ButtonHandler(buttonB, buttonA, gifView, screamPlayer);

        HBox hBox = createHBox(buttonA, buttonB);
        VBox root = createVBox(hBox);

        buttonAHandler.setHBox(hBox);
        buttonAHandler.setRoot(root);
        buttonBHandler.setHBox(hBox);
        buttonBHandler.setRoot(root);

        buttonA.setOnAction(buttonAHandler);
        buttonB.setOnAction(buttonBHandler);

        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.setMaximized(true);
        primaryStage.show();
    }

    private HBox createHBox(Button buttonA, Button buttonB) {
        HBox hBox = new HBox();
        hBox.setSpacing(50);
        hBox.setPadding(new Insets(0, 0, 50, 0));
        hBox.getChildren().addAll(buttonA, buttonB);
        hBox.setAlignment(Pos.CENTER);
        return hBox;
    }

    private VBox createVBox(HBox hBox) {
        VBox vBox = new VBox();
        vBox.getChildren().add(hBox);
        vBox.setAlignment(Pos.CENTER);
        return vBox;
    }
}