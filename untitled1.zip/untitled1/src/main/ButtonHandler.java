package main;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.util.Duration;

public class ButtonHandler implements EventHandler<ActionEvent> {
    private HBox hbox;
    private VBox root;
    private ImageView imageView;
    private MediaView mediaView;
    private MediaPlayer mediaPlayer;
    private Button buttonA;
    private Button buttonB;

    public ButtonHandler(Button buttonB, Button buttonA, ImageView imageView) {
        this.buttonB = buttonB;
        this.buttonA = buttonA;
        this.imageView = imageView;
    }

    public ButtonHandler(Button buttonB, Button buttonA, ImageView imageView, MediaPlayer mediaPlayer) {
        this.buttonB = buttonB;
        this.buttonA = buttonA;
        this.imageView = imageView;
        this.mediaPlayer = mediaPlayer;
    }

    public void setHBox(HBox hbox) {
        this.hbox = hbox;
    }

    public void setRoot(VBox root) {
        this.root = root;
    }

    @Override
    public void handle(ActionEvent event) {
        Button source = (Button) event.getSource();
        if (!root.getChildren().contains(imageView)) {
            hbox.getChildren().remove(buttonA);
            root.getChildren().add(imageView);
            mediaPlayer.seek(Duration.seconds(0));
            mediaPlayer.play();
        } else {
            root.getChildren().remove(imageView);
            if (source == buttonA) {
                hbox.getChildren().add(buttonB);
            } else {
                hbox.getChildren().add(buttonA);
            }
        }
    }
}
